package com.cs.xmind.test;

import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.xmind.core.*;

import com.cs.xmind.utils.ExcelUtils;

public class ximd {

	public static void main(String[] args) {
		String xmindPath="./testdata/test.xmind";
		String excelPath="./testdata/test.xlsx";
		
		
		 Workbook writeWB=ExcelUtils.getExcelFile(excelPath);
		 Sheet writeSheet=writeWB.getSheet("Sheet1");
 
		int i=1,j=0;
		
		
		IWorkbookBuilder builder = Core.getWorkbookBuilder();//初始化builder
        IWorkbook workbook = null;
        try {
            workbook = builder.loadFromPath(xmindPath);//打开XMind文件
        } catch (IOException e) {
            e.printStackTrace();
        } catch (CoreException e) {
            e.printStackTrace();
        }
        ISheet defSheet = workbook.getPrimarySheet();//获取主Sheet
        ITopic rootTopic = defSheet.getRootTopic(); //获取根Topic
        
        System.out.println("xmind 文件根节点是："+rootTopic.getTitleText());
        

        
        ExcelUtils.setCellValue(writeSheet, i, 0, String.valueOf(2));
    	ExcelUtils.setCellValue(writeSheet, i, 1, rootTopic.getTitleText());
        
        List<ITopic> list1=rootTopic.getAllChildren();
        for(ITopic secondTopic: list1){
        	i=i+j+1;
        	
        	System.out.println("xmind 子节点是："+secondTopic.getTitleText());
        	ExcelUtils.setCellValue(writeSheet, i, 0, String.valueOf(3));
        	ExcelUtils.setCellValue(writeSheet, i, 1, secondTopic.getTitleText());
        	
        	List<ITopic> list2=secondTopic.getAllChildren();
        	for(ITopic thirdTopic: list2){
        		j=j+i+1;
        		System.out.println("当前节点下："+secondTopic.getTitleText()+"的子节点是："+thirdTopic.getTitleText());
            	ExcelUtils.setCellValue(writeSheet, j, 0, String.valueOf(4));
            	ExcelUtils.setCellValue(writeSheet, j, 1, thirdTopic.getTitleText());
        	}
        	
        	
        	
        }
        
        ExcelUtils.writeAndsave(excelPath, writeWB);
        
        

	}

}
