package com.cs.xmind.utils;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;



import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ExcelUtils {
	public static XSSFWorkbook workbook;
	public static XSSFSheet worksheet;
	public static XSSFCell cell;
	
	//get workbook object
	public static XSSFWorkbook getExcelFile(String path){
		
		InputStream demoFile;
		try {
			demoFile = new FileInputStream(path);
			workbook = new XSSFWorkbook(demoFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return workbook;
	}
	//get worksheet object
	public static XSSFSheet getSheet(XSSFWorkbook wbName,String sheetName){
		return worksheet=wbName.getSheet(sheetName);

	}
	
	//get worksheet total row
	public static int getSheetCountRow(XSSFSheet wbSH){
		
		return wbSH.getLastRowNum();
	}
	
	//get cell dataֵ
	public static  String getCellData(XSSFSheet wbSH,int rowNumber,int colNumber){
		cell = wbSH.getRow(rowNumber).getCell(colNumber);
		String cellData=null;
		if (cell!=null){

			cellData=cell.getStringCellValue();

		}
		
		return cellData;
	}
	

	//set cell value
	public static void setCellValue(Sheet wbSH,int rowNumber,int colNumber,String setValue){
		Row row=null;
		if(wbSH.getRow(rowNumber)==null){
			 row= wbSH.createRow(rowNumber);
		}else{
			row=wbSH.getRow(rowNumber);
		}
		
		Cell cell=row.createCell(colNumber);
		cell.setCellValue(setValue);
	}
	
	public static void writeAndsave(String datapath,Workbook writeWB){
		FileOutputStream os;
		try {
			os = new FileOutputStream(datapath);
			writeWB.write(os);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
